package BonEsprit.Exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class LogInException extends Exception{}

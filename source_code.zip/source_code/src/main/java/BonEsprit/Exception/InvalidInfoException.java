package BonEsprit.Exception;

import lombok.NoArgsConstructor;

//sai ten dang nhap / mat khau
@NoArgsConstructor
public class InvalidInfoException extends Exception{}

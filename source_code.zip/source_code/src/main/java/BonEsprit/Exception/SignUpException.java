package BonEsprit.Exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class SignUpException extends Exception{}

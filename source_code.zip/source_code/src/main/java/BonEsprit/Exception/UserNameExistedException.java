package BonEsprit.Exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class UserNameExistedException extends Exception {}

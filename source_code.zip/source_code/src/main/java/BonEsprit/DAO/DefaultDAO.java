package BonEsprit.DAO;

public class DefaultDAO {

}
